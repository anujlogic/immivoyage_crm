@extends("layouts.app")
@section("content")
<p>Index page</p>
@endsection