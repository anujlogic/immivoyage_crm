</div>
<style>
	.main-footer{
		text-align:center;
	}
</style>
<footer class="main-footer">
<strong>Copyright &copy; {{ date('Y')}} <a href="http://adminlte.io">Immivoyage.com</a>.</strong>
All rights reserved. 
</footer>
<aside class="control-sidebar control-sidebar-dark">
</aside>
</div>