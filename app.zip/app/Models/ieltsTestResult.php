<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ieltsTestResult extends Model
{
    use HasFactory;
    public $table = "ielts_test_result";
}
