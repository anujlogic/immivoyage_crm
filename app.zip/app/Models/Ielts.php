<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ielts extends Model
{
    use HasFactory;
    public $table="ielts";
}
